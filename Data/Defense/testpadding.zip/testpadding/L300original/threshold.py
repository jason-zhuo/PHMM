#this file is used for stats the result for WF gene test

import sys
import os
import re
import string
resultPath =sys.argv[1]
#correct_count =0.0
totalqueries_count =0.0
pattern = re.compile(r'------- ------ -----    ------- ------ -----   ---- --  -------- -----------')

def readcurrentFile(filename,path):
    global correct_count
    global totalqueries_count
    file_object = open(path)
    all_the_text = file_object.read()
    match = pattern.findall(all_the_text)  # match is the test answer
    totalqueries_count = totalqueries_count+ len(match)
    
    file_object.close()



print("reading " +resultPath)

list = os.listdir(resultPath)
for line in list:
    filepath =os.path.join(resultPath,line)
    if os.path.isdir(filepath):
        continue
    else:
        readcurrentFile(line,filepath)

