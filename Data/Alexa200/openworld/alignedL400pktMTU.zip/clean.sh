#!/bin/bash
echo "clean result.."
rm *.sto
rm *.query
rm hmm*
rm -rf result

echo "done"
