__author__ = 'zhuozhongliu'
#this file is used for stats the result for WF gene test

import sys
import os
import re
import string
#import heatmapdraw as heat
#import numpy as np
#from sklearn.metrics import *
#import numpy as np
#import matplotlib.pyplot as plt
resultPath =sys.argv[1]
test_persite=7
correct_count =0.0
totalqueries_count =0.0
pattern = re.compile('(\\[No hits detected that satisfy reporting thresholds\\])')
pattern2 = re.compile(r'Domain annotation for each model \(and alignments\):\n>> (\d+)')
confusematrix=None

y_true=[]
y_predict=[]

classIDmap=dict()
TN=0
FP=0
def readcurrentFile(filename,path):
    global correct_count
    global totalqueries_count
    global confusematrix
    global classIDmap
    global TN, FP
    file_object = open(path)
    all_the_text = file_object.read( )
    correctAnswer = filename.split("_")[1]
    correctAnswer =string.atoi(correctAnswer)

    for i in range(test_persite):
        y_true.append(correctAnswer)
    #print(all_the_text)
    match = pattern.findall(all_the_text)  # match is the test answer
    totalqueries_count = totalqueries_count+ len(match)

    match_FP=pattern2.findall(all_the_text);
    if match:
        TN=TN+1
    elif match_FP:
        print(filename)
        FP=FP+1

    file_object.close()


print("reading " +resultPath)


list = sorted(os.listdir(resultPath),key=lambda x: int(x.split("_")[1]))
classid=0
for filename in list:
    thisid =int(filename.split("_")[1])
    if classIDmap.has_key(thisid):
        continue
    else:
        classIDmap[thisid]=classid
        classid=classid+1


print(len(list))

confusematrix=[[0 for col in range(len(list))] for row in range(len(list))]

class_names=[i for i in range(len(list))]
for line in list:
    filepath =os.path.join(resultPath,line)
    if os.path.isdir(filepath):
        continue
    else:
        readcurrentFile(line,filepath)

print ("TN/FP %d/%d"%(TN,FP))


#heat.plotHeatmap("", "Site class ID", "Predicted class ID", np.asarray(confusematrix).transpose())
#print(classification_report(np.array(y_predict),np.array(y_true)))


# plt.figure()
# cm= np.array(confusematrix)
# plt.plot_confusion_matrix(cm, classes=class_names,title='Confusion matrix, without normalization')
# plt.show()
# for line in confusematrix:
#     print(str(line)+";")
