#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include <string.h>
#include <sstream>
#include <time.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;

//Data parameters
int FEAT_NUM = 3736; //number of features
const int SITE_NUM = 200; //number of monitored sites
const int INST_NUM = 17; //number of instances per site for distance learning
const int TEST_NUM = 8; //number of instances per site for kNN training

int OPENTEST_NUM = 0; //number of open instances for kNN training/testing
int NEIGHBOUR_NUM = 5; //number of neighbors for kNN

const int RECOPOINTS_NUM = 5; //number of neighbors for distance learning
string folderPath;
//Algorithmic Parameters
float POWER = 0.1; //not used in this code

//Only in old recommendation algorithm
const int RECOLIST_NUM = 10;
const int RECO_NUM = 1;


bool inarray(int ele, int* array, int len) {
	for (int i = 0; i < len; i++) {
		if (array[i] == ele)
			return 1;
	}
	return 0;
}

void alg_init_weight(float** feat, float* weight) {
	for (int i = 0; i < FEAT_NUM; i++) {
		weight[i] = (rand() % 100) / 100.0 + 0.5;
	}
	/*float sum = 0;
	for (int j = 0; j < FEAT_NUM; j++) {
		if (abs(weight[j]) > sum) {
		sum += abs(weight[j]);
		}
	}
	for (int j = 0; j < FEAT_NUM; j++) {
		weight[j] = weight[j]/sum * 1000;
	}*/
}

float dist(float* feat1, float* feat2, float* weight, float power) {
	float toret = 0;
	for (int i = 0; i < FEAT_NUM; i++) {
		if (feat1[i] != -1 and feat2[i] != -1) {
			toret += weight[i] * abs(feat1[i] - feat2[i]);
		}
	}
	return toret;
}

void alg_recommend2(float** feat, float* weight, int start, int end) {

	float* distlist = new float[SITE_NUM * INST_NUM];
	int* recogoodlist = new int[RECOPOINTS_NUM];
	int* recobadlist = new int[RECOPOINTS_NUM];

	for (int i = start; i < end; i++) {
		printf("\rLearning distance... %d (%d-%d)", i, start, end);
		fflush(stdout);
		int cur_site = i/INST_NUM;
		int cur_inst = i % INST_NUM;

		float pointbadness = 0;
		float maxgooddist = 0;

		for (int k = 0; k < SITE_NUM*INST_NUM; k++) {
			distlist[k] = dist(feat[i], feat[k], weight, POWER);
		}
		float max = *max_element(distlist, distlist+SITE_NUM*INST_NUM);
		distlist[i] = max;
		for (int k = 0; k < RECOPOINTS_NUM; k++) {
			int ind = min_element(distlist+cur_site*INST_NUM, distlist+(cur_site+1)*INST_NUM) - distlist;
			if (distlist[ind] > maxgooddist) maxgooddist = distlist[ind];
			distlist[ind] = max;
			recogoodlist[k] = ind;
		}
		for (int k = 0; k < INST_NUM; k++) {
			distlist[cur_site*INST_NUM+k] = max;
		}
		for (int k = 0; k < RECOPOINTS_NUM; k++) {
			int ind = min_element(distlist, distlist+ SITE_NUM * INST_NUM) - distlist;
			if (distlist[ind] <= maxgooddist) pointbadness += 1;
			distlist[ind] = max;
			recobadlist[k] = ind;
		}

		pointbadness /= float(RECOPOINTS_NUM);
		pointbadness += 0.2;
		/*
		if (i == 0) {
			float gooddist = 0;
			float baddist = 0;
			printf("Current point: %d\n", i);
			printf("Bad points:\n");
			for (int k = 0; k < RECOPOINTS_NUM; k++) {
				printf("%d, %f\n", recobadlist[k], dist(feat[i], feat[recobadlist[k]], weight, POWER));	
				baddist += dist(feat[i], feat[recobadlist[k]], weight, POWER);
			}

			printf("Good points:\n");
			for (int k = 0; k < RECOPOINTS_NUM; k++) {
				printf("%d, %f\n", recogoodlist[k], dist(feat[i], feat[recogoodlist[k]], weight, POWER));
				gooddist += dist(feat[i], feat[recogoodlist[k]], weight, POWER);
			}

			printf("Total bad distance: %f\n", baddist);
			printf("Total good distance: %f\n", gooddist);
		}*/

		float* featdist = new float[FEAT_NUM];
		for (int f = 0; f < FEAT_NUM; f++) {
			featdist[f] = 0;
		}
		int* badlist = new int[FEAT_NUM];
		int minbadlist = 0;
		int countbadlist = 0;
		//printf("%d ", badlist[3]);
		for (int f = 0; f < FEAT_NUM; f++) {
			if (weight[f] == 0) badlist[f] == 0;
			else {
			float maxgood = 0;
			int countbad = 0;
			for (int k = 0; k < RECOPOINTS_NUM; k++) {
				float n = abs(feat[i][f] - feat[recogoodlist[k]][f]);
				if (feat[i][f] == -1 or feat[recobadlist[k]][f] == -1) 
					n = 0;
				if (n >= maxgood) maxgood = n;
			}
			for (int k = 0; k < RECOPOINTS_NUM; k++) {
				float n = abs(feat[i][f] - feat[recobadlist[k]][f]);
				if (feat[i][f] == -1 or feat[recobadlist[k]][f] == -1) 
					n = 0;
				//if (f == 3) {
				//	printf("%d %d %f %f\n", i, k, n, maxgood);
				//}
				featdist[f] += n;
				if (n <= maxgood) countbad += 1;
			}
			badlist[f] = countbad;
			if (countbad < minbadlist) minbadlist = countbad;	
			}
		}

		for (int f = 0; f < FEAT_NUM; f++) {
			if (badlist[f] != minbadlist) countbadlist += 1;
		}
		int* w0id = new int[countbadlist];
		float* change = new float[countbadlist];

		int temp = 0;
		float C1 = 0;
		float C2 = 0;
		for (int f = 0; f < FEAT_NUM; f++) {
			if (badlist[f] != minbadlist) {
				w0id[temp] = f;
				change[temp] = weight[f] * 0.01 * badlist[f]/float(RECOPOINTS_NUM) * pointbadness;
				//if (change[temp] < 1.0/1000) change[temp] = weight[f];
				C1 += change[temp] * featdist[f];
				C2 += change[temp];
				weight[f] -= change[temp];
				temp += 1;
			}
		}

		/*if (i == 0) {
			printf("%d %f %f\n", countbadlist, C1, C2);
			for (int f = 0; f < 30; f++) {
				printf("%f %f\n", weight[f], featdist[f]);
			}
		}*/
		float totalfd = 0;
		for (int f = 0; f < FEAT_NUM; f++) {
			if (badlist[f] == minbadlist and weight[f] > 0) {
				totalfd += featdist[f];
			}
		}

		for (int f = 0; f < FEAT_NUM; f++) {
			if (badlist[f] == minbadlist and weight[f] > 0) {
				weight[f] += C1/(totalfd);
			}
		}

		/*if (i == 0) {
			printf("%d %f %f\n", countbadlist, C1, C2);
			for (int f = 0; f < 30; f++) {
				printf("%f %f\n", weight[f], featdist[f]);
			}
		}*/

		/*if (i == 0) {
			float gooddist = 0;
			float baddist = 0;
			printf("Current point: %d\n", i);
			printf("Bad points:\n");
			for (int k = 0; k < RECOPOINTS_NUM; k++) {
				printf("%d, %f\n", recobadlist[k], dist(feat[i], feat[recobadlist[k]], weight, POWER));	
				baddist += dist(feat[i], feat[recobadlist[k]], weight, POWER);
			}

			printf("Good points:\n");
			for (int k = 0; k < RECOPOINTS_NUM; k++) {
				printf("%d, %f\n", recogoodlist[k], dist(feat[i], feat[recogoodlist[k]], weight, POWER));
				gooddist += dist(feat[i], feat[recogoodlist[k]], weight, POWER);
			}

			printf("Total bad distance: %f\n", baddist);
			printf("Total good distance: %f\n", gooddist);
		}*/
		delete[] featdist;
		delete[] w0id;
		delete[] change;
		delete[] badlist;
	}


	for (int j = 0; j < FEAT_NUM; j++) {
		if (weight[j] > 0)
			weight[j] *= (0.9 + (rand() % 100) / 500.0);
	}
	printf("\n");
	delete[] distlist;
	delete[] recobadlist;
	delete[] recogoodlist;



}


void accuracy(float** closedfeat, float* weight, float** openfeat, float & tp, float & tn) {

	tp = 0;
	tn = 0;

	float** feat = new float*[SITE_NUM*TEST_NUM + OPENTEST_NUM];

	for (int i = 0; i < SITE_NUM*TEST_NUM; i++) {
		feat[i] = closedfeat[i];
	}
	for (int i = 0; i < OPENTEST_NUM; i++) {
		feat[i + SITE_NUM * TEST_NUM] = openfeat[i];
	}

	float* distlist = new float[SITE_NUM * TEST_NUM + OPENTEST_NUM];
	int* classlist = new int[SITE_NUM + 1];

	float* opendistlist = new float[OPENTEST_NUM];

	for (int is = 0; is < SITE_NUM*TEST_NUM + OPENTEST_NUM; is++) {
                // 2 * 10 + 20
		printf("\rComputing accuracy... %d (%d-%d)\n", is, 0, SITE_NUM*TEST_NUM + OPENTEST_NUM);
		fflush(stdout);
		for (int i = 0; i < SITE_NUM+1; i++) {
			classlist[i] = 0;
		}
		int maxclass = 0;
		for (int at = 0; at < SITE_NUM * TEST_NUM + OPENTEST_NUM; at++) {
			distlist[at] = dist(feat[is], feat[at], weight, POWER);
		}
		float max = *max_element(distlist, distlist+SITE_NUM*TEST_NUM+OPENTEST_NUM);
		distlist[is] = max; // 不会再找这个样本了
                int myclassID=0;
		for (int i = 0; i < NEIGHBOUR_NUM; i++) {
			int ind = find(distlist, distlist + SITE_NUM*TEST_NUM+OPENTEST_NUM, *min_element(distlist, distlist+SITE_NUM*TEST_NUM+OPENTEST_NUM)) - distlist;
			int classind = 0;
                        //cout<<"#"<<is<<": " << ind << endl;  
                        //最近邻的索引如果在 测试范围内（在monitor pages 的测试范围内，则认为是该类）
			if (ind < SITE_NUM * TEST_NUM) {
				classind = ind/TEST_NUM;
                                myclassID= classind;
			}
			else {
                           //最近邻的索引如果不在测试范围内（即不在monitor pages 的测试范围内，则认为该类为非monitored pages）
				classind = SITE_NUM;
			}
			classlist[classind] += 1;
			if (classlist[classind] > maxclass) {
				maxclass = classlist[classind];
			}
			distlist[ind] = max;// 不会再找这个样本了
		}
                 
		int trueclass = is/TEST_NUM;
                
		if (trueclass > SITE_NUM) trueclass = SITE_NUM;
                //cout<<"#"<<is<<": " << myclassID << " true class "<< trueclass<< endl;  
		int countclass = 0;
		int hascorrect = 0;

		int hasconsensus = 0;
		for (int i = 0; i < SITE_NUM+1; i++) {
			if (classlist[i] == NEIGHBOUR_NUM) {
				hasconsensus = 1;
			}
		}
		if (hasconsensus == 0) {
			for (int i = 0; i < SITE_NUM; i++) {
				classlist[i] = 0;
			}
			classlist[SITE_NUM] = 1;
			maxclass = 1;
		}

		for (int i = 0; i < SITE_NUM+1; i++) {
			if (classlist[i] == maxclass) {
				countclass += 1;
				if (i == trueclass) {
					hascorrect = 1;
				}
			}
		}
               
		float thisacc = 0;
		if (hascorrect == 1) {
			thisacc = 1.0/countclass;
		}
		if (trueclass == SITE_NUM) {
			tn += thisacc;
		}
		else { 
			tp += thisacc;
		}
		
	}

	printf("\n");
       
        
	delete[] distlist;
	delete[] classlist;
	delete[] opendistlist;
	delete[] feat;
	
	tp /= SITE_NUM*TEST_NUM;
	if (OPENTEST_NUM > 0)	tn /= OPENTEST_NUM;     
	else tn = 1;
         cout<< "tp: " <<tp<< " tn: "<< tn<<endl;
}


int main(int argc, char** argv) {

	//int OPENTEST_list [12] = {0, 10, 50, 100, 200, 300, 500, 1000, 1500, 2000, 3000, 5000};
    int OPENTEST_list [12] = {0, 10, 20, 100, 200, 300, 500, 1000, 1500, 2000, 3000, 5000};
	int NEIGHBOUR_list [12] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15};

	if(argc == 4){
		folderPath = argv[1];
		int OPENTEST_ind = atoi(argv[2]); 
		int NEIGHBOUR_ind = atoi(argv[3]); 
               
		OPENTEST_NUM = OPENTEST_list[OPENTEST_ind % 12];
		NEIGHBOUR_NUM = NEIGHBOUR_list[NEIGHBOUR_ind % 12];
                cout<< "123123123 OPENTEST_NUM: "<< OPENTEST_NUM << " NEIGHBOUR_NUM: "<< NEIGHBOUR_NUM<< endl;
	}else{
            cout<< " param not corret exiting.. "<<endl;
            exit(1);
        }

	srand(time(NULL));

	float** feat = new float*[SITE_NUM*INST_NUM];
	float** testfeat = new float*[SITE_NUM*TEST_NUM];
	float** opentestfeat = new float*[OPENTEST_NUM];  

	for (int i = 0; i < SITE_NUM*INST_NUM; i++) {
		feat[i] = new float[FEAT_NUM];
	}
	for (int i = 0; i < SITE_NUM*TEST_NUM; i++) {
		testfeat[i] = new float[FEAT_NUM];
	}
	for (int i = 0; i < OPENTEST_NUM; i++) {
		opentestfeat[i] = new float[FEAT_NUM];  
	}

	for (int cur_site = 0; cur_site < SITE_NUM; cur_site++) {
		int real_inst = 0;
		for (int cur_inst = 0; cur_inst < INST_NUM; cur_inst++) {
			int gotfile = 0;
			ifstream fread;
			while (gotfile == 0) {
				ostringstream freadnamestream;
				freadnamestream << folderPath << cur_site << "_" << real_inst << "f";                                                          
				string freadname = freadnamestream.str();

				fread.open(freadname.c_str());
				if (fread.is_open()) {
                                    gotfile = 1;
                                    cout<< "train reading "<< freadname<<endl; 
                                }
				real_inst++;
			}
			string str = "";
			getline(fread, str);
			fread.close();

			string tempstr = "";
			int feat_count = 0;
			for (int i = 0; i < str.length(); i++) {
				if (str[i] == ' ') {
					if (tempstr.c_str()[1] == 'X') {
						feat[cur_site * INST_NUM + cur_inst][feat_count] = -1;
					}
					else {
						feat[cur_site * INST_NUM + cur_inst][feat_count] = atof(tempstr.c_str());
					}	
					feat_count += 1;
					tempstr = "";
				}
				else {
					tempstr += str[i];
				}
			}
			
		}
		cout<<"start reading test "<<endl;
		for (int cur_inst = 0; cur_inst < TEST_NUM; cur_inst++) {
			int gotfile = 0;
			ifstream fread;
			string freadname;
			while (gotfile == 0) {
				ostringstream freadnamestream;
				freadnamestream << folderPath << cur_site << "_" << real_inst << "f";
				freadname = freadnamestream.str();
                 //cout<< freadname<<endl;                
				fread.open(freadname.c_str());
				if (fread.is_open()) {
                                    gotfile = 1;
                                    cout<< "test reading "<< freadname<<endl;
                                }
				real_inst++;
			}
			string str = "";
			getline(fread, str);
			fread.close();

			string tempstr = "";
			int feat_count = 0;
			for (int i = 0; i < str.length(); i++) {
				if (str[i] == ' ') {
					if (tempstr.c_str()[1] == 'X') {
						testfeat[cur_site * TEST_NUM + cur_inst][feat_count] = -1;
					}
					else {
						testfeat[cur_site * TEST_NUM + cur_inst][feat_count] = atof(tempstr.c_str());
					}	
					feat_count += 1;
					tempstr = "";
				}
				else {
					tempstr += str[i];
				}
			}
		}
	}

	for (int cur_site = 0; cur_site < OPENTEST_NUM; cur_site++) {
			int gotfile = 0;
			ifstream fread;
			string freadname;
                       
			while (gotfile == 0) {
				ostringstream freadnamestream;
				freadnamestream << folderPath << cur_site << "f";
				freadname = freadnamestream.str();
				fread.open(freadname.c_str());                             
				if (fread.is_open()) {
                                    gotfile = 1;
                                    cout<< "open test reading "<< freadname<<endl; 
                                }
			}
			string str = "";
			getline(fread, str);
                        
			fread.close();
                         
			string tempstr = "";
			int feat_count = 0;
			for (int i = 0; i < str.length(); i++) {
				if (str[i] == ' ') {
					if (tempstr.c_str()[1] == 'X') {
						opentestfeat[cur_site][feat_count] = -1;
					}
					else {
						opentestfeat[cur_site][feat_count] = atof(tempstr.c_str());
					}	
					feat_count += 1;
					tempstr = "";
				}
				else {
					tempstr += str[i];
				}
			}
	}



	float * weight = new float[FEAT_NUM];
	float * value = new float[FEAT_NUM];

	int TRIAL_NUM = 1;
	int SUBROUND_NUM = 5;
	float maxacc = 0;
	alg_init_weight(feat, weight);

	float * prevweight = new float[FEAT_NUM];
	for (int i = 0; i < FEAT_NUM; i++) {
		prevweight[i] = weight[i];
	}

	clock_t t1, t2;
	alg_init_weight(feat, weight);
	for (int trial = 0; trial < TRIAL_NUM; trial++) {
		for (int subround = 0; subround < SUBROUND_NUM; subround++) {
			int start = (SITE_NUM * INST_NUM)/SUBROUND_NUM * subround;
			int end = (SITE_NUM * INST_NUM)/SUBROUND_NUM * (subround+1);
			alg_recommend2(feat, weight, start, end);
			float tp, tn;
//			t1 = clock();
			accuracy(testfeat, weight, opentestfeat, tp, tn);
//			t2 = clock();
//			printf("Time taken: %f\n", (float)(t2-t1)/(CLOCKS_PER_SEC));
			if (tp > maxacc) maxacc = tp;
			printf("Round %d-%d, accuracy: %f %f, best accuracy: %f\n", trial,subround,tp, tn, maxacc);
		}
	}

	FILE * weightfile;
	weightfile = fopen("weights", "w");
	for (int i = 0; i < FEAT_NUM; i++) {
		fprintf(weightfile, "%f ", weight[i] * 1000);
	}
	fclose(weightfile);

	for (int i = 0; i < SITE_NUM * INST_NUM; i++) {
		delete[] feat[i];
	}
	delete[] feat;
	for (int i = 0; i < SITE_NUM * TEST_NUM; i++) {
		delete[] testfeat[i];
	}
	delete[] testfeat;
	for (int i = 0; i < OPENTEST_NUM; i++) {
		delete[] opentestfeat[i];
	}
	delete[] opentestfeat;

	delete[] prevweight;
	delete[] weight;
	delete[] value;
	return 0;
}
